<?php
require_once "Bootstrap.phtml";
require_once "GoogleFront.phtml";
require_once "FontAwesome.phtml";
require_once "Iconscout.phtml";
require_once "iziToast.phtml";
require_once "ScrollReveal.phtml";
require_once "Normalize.phtml";
require_once "TyroLink.phtml";
require_once "JQuery.phtml";
require_once "GoogleAnalytics.phtml";

?>
