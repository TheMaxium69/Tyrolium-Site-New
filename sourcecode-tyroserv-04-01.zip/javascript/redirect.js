function redirect(page){

    if (page === 1){
        window.location.href='./';
    }

    if (page === 2){
        window.location.href='./service.php';
    }

    if (page === 3){
        window.location.href='./project.php';
    }

    if (page === 4){
        window.location.href='./collaboration.php';
    }

    if (page === 5){
        window.location.href='./story.php';
    }

    if (page === 6){
        window.location.href='./account.php';
    }
}