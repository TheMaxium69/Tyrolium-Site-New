<?php

function footer(){

    require "env.php";

    require_once "composant/footer.phtml";

}

?>