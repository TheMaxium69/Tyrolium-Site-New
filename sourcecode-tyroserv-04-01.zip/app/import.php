<?php

require_once "env.php";
require_once "head.php";
require_once "navbar.php";
require_once "footer.php";
require_once "particule.php";
require_once "tyrobtn.php";

?>