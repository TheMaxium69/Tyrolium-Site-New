<?php

function particule(){
    require_once "composant/particule.phtml";
}

?>