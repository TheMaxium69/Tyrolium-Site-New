<?php

class sendRequest{
    public $id;
    public $raison;
    public $prestation;
    public $web;
    public $mc;
    public $projet;
    public $firstName;
    public $lastName;
    public $email;
    public $phoneNumber;
    public $content;
}
